from .rival10 import RIVAL10
from .local_rival10 import LocalRIVAL10